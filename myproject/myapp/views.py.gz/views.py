# myapp/views.py
from django.shortcuts import render
from django.db import connection
from django.http import JsonResponse

#totally unnecessary
def emulate_api_call(numid):
    # Simulate data you might receive from an API
    data = {"message": "Emulating API call", "status": "success"}

    # Return a JsonResponse
    return JsonResponse(data)

def find_names_by_numid(numid):
    with connection.cursor() as cursor:
        query = "SELECT * FROM myapp_randomname WHERE num_id = %s"
        cursor.execute(query, [numid])
        row = cursor.fetchone()

        if row:
            return {
                "First Name": row[1],
                "Middle Name": row[2],
                "Last Name": row[3],
                "Gender": row[4],
                "NumID": row[5]
            }

    return None

def index(request):
    return render(request, 'myapp/index.html')

def query_names(request):
    if request.method == 'POST':
        numid_to_search = request.POST.get('numid', None)

        if numid_to_search is not None:
            found_names = find_names_by_numid(numid_to_search)
            if found_names:
                return JsonResponse(found_names) #return render(request, 'myapp/result.html', {'found_names': found_names})
            else:
                return render(request, 'myapp/result.html', {'message': f"Failed, check number and try again. You searched,: {numid_to_search}"})
        else:
            return render(request, 'myapp/result.html', {'message': "NumID parameter is missing."})
    else:
        # Redirect to the index page if accessed directly
        return index(request)
