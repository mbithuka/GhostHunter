import csv
from django.core.management.base import BaseCommand
from myapp.models import RandomName

class Command(BaseCommand):
    help = 'Import data from CSV file to RandomName model'

    def handle(self, *args, **options):
        csv_file_path = "random_names.csv"

        with open(csv_file_path, newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                RandomName.objects.create(
                    first_name=row['First Name'],
                    middle_name=row['Middle Name'],
                    last_name=row['Last Name'],
                    gender=row['Gender'],
                    num_id=row['NumID']
                )

        self.stdout.write(self.style.SUCCESS('Data imported successfully!'))
