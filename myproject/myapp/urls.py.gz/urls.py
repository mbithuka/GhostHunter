# myapp/urls.py
from django.urls import path
from . import views
from .views import emulate_api_call

app_name = 'myapp'

urlpatterns = [
    path('', views.index, name='index'),
    path('query_names/', views.query_names, name='query_names'),
    path('emulate-api/', emulate_api_call, name='emulate_api_call'),
]
